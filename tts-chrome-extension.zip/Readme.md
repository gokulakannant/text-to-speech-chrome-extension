# Text To Speech (TTS) Chrome Extension

A light weight google chrome extension for convert the text into speech.